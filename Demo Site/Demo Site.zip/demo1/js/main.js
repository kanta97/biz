particlesJS.load("bubble", "json/particles.json", function () {});
particlesJS.load("particles-js", "json/particles.json", function () {});
